## Calculator Service: Project Overview
 - A modular Spring Boot project implementing a RESTful calculator API with Kafka integration, supporting operations such as:-
     * addition, 
     * subtraction, 
     * multiplication, 
     * division. 
 - The project uses Docker and Docker Compose for containerization and testing.

## Project Structure
This project follows a modular Hexagonal Architecture:

## Modules:
- calculator: Contains business logic (domain and core services).
- calculator-api: REST API implementation.
- calculator-messaging: Kafka producer/consumer logic.

## Technologies:
- Spring Boot: Framework for API, messaging, and core business logic.
- Kafka: Messaging system for inter-module communication.
- Zookeeper: Service registry for Kafka brokers.
- Docker: Containerization.
- Postman: API testing.
- JUnit 5: Unit testing.

 ## Features
  - Modular Spring Boot architecture.
  - Dockerized for seamless deployment.
  - Kafka integration for inter-module communication.
  - RESTful API with dynamic payload validation.
  - Comprehensive unit and integration tests(POSTMAN).

## Docker Implementation
- Dockerfile Setup
- Each module (calculator-api, calculator-messaging) includes a Dockerfile in its respective directories.

### calculator-api Dockerfile
##### ###############################
    FROM openjdk:17-jdk-slim
    WORKDIR /app
    COPY target/calculator-api-0.0.1-SNAPSHOT.jar app.jar
    ENTRYPOINT ["java", "-jar", "app.jar"]

### calculator-messaging Dockerfile:

    FROM openjdk:17-jdk-slim
    WORKDIR /app
    COPY target/calculator-messaging-0.0.1-SNAPSHOT.jar app.jar
    ENTRYPOINT ["java", "-jar", "app.jar"]
## Building Docker Images
- all above images are contained in the docker-compose
- Build Docker images for each module 
### Build the calculator-api image
    docker build -t calculator-api ./calculator-api

### Build the calculator-messaging image
    docker build -t calculator-messaging ./calculator-messaging

## Docker Compose
- Compose File
  - The docker-compose.yml file defines the services, including zookeeper, kafka, and application modules.
    - docker file. 

            docker/docker-compose.yml
 ## Create Docker images, containers, volumes and networks
- execute the below command using docker-file
  - for this version (V2) docker-compose command has been replaced by docker compose.
    
        docker compose -f .docker/docker-compose.yml up -d
- the above command will download and create images and containers, provided all configurations are correctly done
## Start the containers:

    docker compose -f .docker/docker-compose.yml up -d
  
 ## Verify the Setup
 ### Check Running Containers:
    docker ps
## Access the API:

    calculator-api: http://localhost:8080
    calculator-messaging: http://localhost:8081

## View Logs:
    docker logs calculator-api
    docker logs calculator-messaging
## Create Volumes
    docker volume create kafka-data
## Verify Volume Lists
    docker volume ls
## Inspect the Volume
- Inspect the kafka-data volume to confirm its location.

        docker volume inspect kafka-data
## Stop and start Docker Services

    docker compose -f .docker/docker-compose.yml up -d
## Stop all Docker process 
    docker stop $(docker ps -a -q)
## stop specific docker container or process
    docker stop <container_name or container_id>
# Running And Application Testing

### Ensure the application and its dependencies (Kafka, Zookeeper, etc.) are running:

  - Start Kafka and Zookeeper using Docker Compose.
  
        docker compose -f .docker/docker-compose.yml up -d
### Start the calculator-api application:
    mvn clean install (validates all tests)
    mvn clean install -DskipTests (skips all tests)

- From your IDE, run the CalculatorApiApplication class.
- Alternatively, use Maven to package and run the application.
  
      mvn clean package
      java -jar target/calculator-api.jar

# Test the API Endpoints
Endpoint 1: Addition.

    URL: http://localhost:8080/api/v1/calculator/ADD
    Method: POST
    Request Body:

        {
            "a": 5,
            "b": 7
        }
## Steps in Postman:

- Open a new tab in Postman.
- Select POST as the HTTP method.
- Enter the URL http://localhost:8080/api/v1/calculator/ADD.
- Go to the Body tab, select raw, and set the format to JSON.
- Paste the request body above into the editor.
  - Click Send.

        Expected Response:

            {
                "result": 12
            }
  
Endpoint 2: Subtraction.

    URL: http://localhost:8080/api/v1/calculator/SUBTRACT
    Method: POST
    Request Body:

    json format

        {
            "a": 7,
            "b": 5
        }
Steps: Follow the same steps as for the Addition endpoint but update.

- The URL to /SUBTRACT.
  - The operands in the request body.

        Expected Response:
        json format

          {
            "result": 35
          }
  
- Endpoint 3: Multiplication
  - URL: http://localhost:8080/api/v1/calculator/MULTIPLY

        Method: POST
        Request Body:
        json format

        {
            "a": 7,
            "b": 5
        }
  - 
        Expected Response.

        json format

        {
            "result": 35
        }

- Endpoint 4: Division
  - URL: http://localhost:8080/api/v1/calculator/DIVIDE.

        Method: POST
        Request Body:

        json format

        {
            "a": 5,
            "b": 2
        }
    
- Expected Response.

      json format

        {
              "result": 25
        }
- Invalid Operation : Division by zero.

  - Request.
  
         json format

          {
                "a": 5,
                "b": 0
          }
- Expected Response

        json format
 
        {
        "error": " :: Cannot divide by zero"
        }