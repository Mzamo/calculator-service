package com.mzetx.api;

import com.mzetx.calculator.domain.CalculationInputs;
import com.mzetx.calculator.domain.CalculationResults;
import com.mzetx.calculator.port.primary.CalculationHandler;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/calculator")
public class CalculatorController {

    private final CalculationHandler calculationHandler;

    public CalculatorController(CalculationHandler calculationHandler) {
        this.calculationHandler = calculationHandler;
    }

    @PostMapping(value = "/{calculatorOperation}", produces = "application/json")
    public CalculationResults calculate(@PathVariable("calculatorOperation") String calculatorOperation,
                                        @Valid @RequestBody CalculationInputs calculationInputs){
        return calculationHandler.calculate(calculatorOperation, calculationInputs);
    }
}
