package com.mzetx.exception;

import com.mzetx.api.CalculatorController;
import com.mzetx.calculator.domain.CalculationInputs;
import com.mzetx.calculator.port.primary.CalculationHandler;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CalculatorController.class)
class GlobalExceptionHandlerTest {
@Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private CalculationHandler calculationHandler; // Mocked bean

    @Test
    void handleValidationExceptions() {
    }

    @Test
    void should_fail_to_handle_illegalArgumentException_as_value_a_is_null() throws Exception {
        String invalidRequest = """
            {
                "a": null,
                "b": 5
            }
            """;

        mockMvc.perform(post("/api/v1/calculator/ADD")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(invalidRequest))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.a").value("Value (a) must not be null"));
    }

    @Test
    void should_fail_to_handle_illegalArgumentException_as_value_b_is_null() throws Exception {
        String invalidRequest = """
            {
                "a": 5,
                "b": null
            }
            """;

        mockMvc.perform(post("/api/v1/calculator/ADD")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(invalidRequest))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.b").value("Value (b) must not be null"));
    }

    @Test
    void should_fail_to_divide_any_value_with_zero_handleIllegalArgumentException() throws Exception {
        String validRequest = """
            {
                "a": 10,
                "b": 0
            }
            """;

        // Mock behavior for divide by zero
        when(calculationHandler.calculate(eq("DIVIDE"), any(CalculationInputs.class)))
                .thenThrow(new IllegalArgumentException("Division by zero is not allowed"));

        mockMvc.perform(post("/api/v1/calculator/DIVIDE")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(validRequest))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Division by zero is not allowed"));

        verify(calculationHandler, times(1)).calculate(eq("DIVIDE"), any(CalculationInputs.class));
    }
}
