package com.mzetx.calculator.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class KafkaConfigs {
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${spring.kafka.topic.request}")
    private String requestTopic;

    @Value("${spring.kafka.topic.response}")
    private String responseTopic;

    public String getBootstrapServers() {
        return bootstrapServers;
    }

    public String getRequestTopic() {
        return requestTopic;
    }

    public String getResponseTopic() {
        return responseTopic;
    }
}
