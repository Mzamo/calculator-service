package com.mzetx.calculator.domain;

import jakarta.validation.constraints.NotNull;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
@Service
public class CalculationInputs {
    @NotNull(message = "Value (a) must not be null")
    private BigDecimal a;
    @NotNull(message = "Value (b) must not be null")
    private BigDecimal b;

    public CalculationInputs(BigDecimal a, BigDecimal b) {
        this.a = a;
        this.b = b;
    }

    /**
     * Default constructor : Jackson uses this constructor to create an instance of the class during deserialization.
      */
    public CalculationInputs() {
    }

    public BigDecimal getA() {
        return a;
    }

    public void setA(BigDecimal a) {
        this.a = a;
    }

    public BigDecimal getB() {
        return b;
    }

    public void setB(BigDecimal b) {
        this.b = b;
    }
}