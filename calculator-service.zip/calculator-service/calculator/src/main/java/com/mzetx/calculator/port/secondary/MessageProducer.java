package com.mzetx.calculator.port.secondary;

public interface MessageProducer {
    void sendMessage(String message);
}
