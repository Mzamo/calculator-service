package com.mzetx.calculator.helper;

public enum CalculatorOperationType {
    ADD, SUBTRACT, MULTIPLY, ZERO
}
