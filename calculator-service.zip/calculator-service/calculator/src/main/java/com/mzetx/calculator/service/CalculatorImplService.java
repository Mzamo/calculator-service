package com.mzetx.calculator.service;

import com.mzetx.calculator.domain.CalculationInputs;
import com.mzetx.calculator.domain.CalculationResults;
import com.mzetx.calculator.port.primary.CalculationHandler;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
public class CalculatorImplService implements CalculationHandler {
    @Override
    public CalculationResults calculate(String calOperation, CalculationInputs calculationInputs) {
        BigDecimal calculationResults;
        switch (calOperation.toUpperCase()){
            case "ADD":
                calculationResults = calculationInputs.getA().add(calculationInputs.getB());
                break;
            case "SUBTRACT":
                calculationResults = calculationInputs.getA().subtract(calculationInputs.getB());
                break;
            case "MULTIPLY":
                calculationResults = calculationInputs.getA().multiply(calculationInputs.getB());
                break;
            case "DIVIDE":
                if (calculationInputs.getB().compareTo(BigDecimal.ZERO) == 0) {
                    throw new IllegalArgumentException(" :: Cannot divide by zero");
                }
                calculationResults = calculationInputs.getA().divide(calculationInputs.getB(), 2, RoundingMode.HALF_UP);
                break;
            default:
                throw new UnsupportedOperationException("Invalid operation");
        }
        return new CalculationResults(calculationResults);
    }
}
