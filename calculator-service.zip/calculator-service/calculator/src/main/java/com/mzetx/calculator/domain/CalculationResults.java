package com.mzetx.calculator.domain;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;

public class CalculationResults {
    private BigDecimal result;

    public CalculationResults(BigDecimal result) {
        this.result = result;
    }

    public BigDecimal getResult() {
        return result;
    }
}