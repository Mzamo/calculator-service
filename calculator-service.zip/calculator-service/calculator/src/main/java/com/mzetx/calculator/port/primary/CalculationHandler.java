package com.mzetx.calculator.port.primary;

import com.mzetx.calculator.domain.CalculationInputs;
import com.mzetx.calculator.domain.CalculationResults;

public interface CalculationHandler {
    CalculationResults calculate(String calOperation, CalculationInputs calculationInputs);

}
